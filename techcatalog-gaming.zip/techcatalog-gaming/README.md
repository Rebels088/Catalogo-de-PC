# TechCatalog Gaming

Catálogo visual de equipos tecnológicos creado con HTML, CSS y JavaScript puro, preparado para GitHub Pages. No incluye carrito, pagos ni venta directa.

## Funciones

- Categorías: Desktop, Laptop, Workstation y dispositivos móviles.
- Búsqueda por nombre, marca, categoría y especificaciones.
- Filtro por categoría.
- Orden alfabético.
- Ficha de detalle para cada producto.
- Equipos relacionados por categoría.
- Diseño adaptable a computadoras, tabletas y móviles.
- Catálogo editable manualmente en `data/productos.js`.

## Estructura

```text
techcatalog-gaming/
├── index.html
├── producto.html
├── styles.css
├── data/
│   └── productos.js
├── js/
│   ├── catalogo.js
│   └── detalle.js
└── README.md
```

## Probar localmente

Abre `index.html` en un navegador moderno. Para una prueba más fiel, puedes usar la extensión Live Server de Visual Studio Code.

## Añadir o editar equipos

Edita `data/productos.js`. Cada objeto de producto utiliza esta estructura:

```js
{
  id: "laptop-003",
  name: "Nombre del equipo",
  brand: "Marca",
  model: "Modelo",
  category: "Laptop",
  featured: false,
  image: "https://direccion-de-la-imagen",
  imageAlt: "Descripción de la imagen",
  summary: "Descripción breve del equipo.",
  specs: {
    "Procesador": "Modelo del procesador",
    "Memoria RAM": "16 GB",
    "Almacenamiento": "512 GB SSD"
  }
}
```

Reglas:
- El `id` debe ser único y no cambiar si quieres conservar los enlaces.
- `category` debe ser exactamente `Desktop`, `Laptop`, `Workstation` o `Movil`.
- Usa una dirección de imagen válida o una ruta local como `assets/nombre-imagen.jpg`.
- Verifica que las especificaciones sean correctas antes de publicarlas.
- Los productos de este proyecto son ejemplos ilustrativos; no representan necesariamente productos comerciales ni configuraciones verificadas.

## Publicar en GitHub Pages

1. Crea un repositorio llamado `techcatalog-gaming` en GitHub.
2. Sube todos los archivos y carpetas manteniendo la estructura.
3. Abre **Settings → Pages**.
4. En **Build and deployment**, elige **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/(root)`, y guarda.
6. Espera la publicación y abre la URL que GitHub Pages muestra en esa misma sección.

No se requiere Node.js, compilación ni un servidor backend. Las imágenes de ejemplo y las fuentes tipográficas se cargan desde servicios externos; para que todo funcione sin depender de esos servicios, guarda los recursos localmente y actualiza sus rutas.
